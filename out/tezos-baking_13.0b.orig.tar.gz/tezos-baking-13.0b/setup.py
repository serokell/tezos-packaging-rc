
from setuptools import setup

setup(
    name='tezos-baking',
    packages=['tezos_baking'],
    version='13.0b',
    entry_points=dict(
        console_scripts=[
            'tezos-setup-wizard=tezos_baking.tezos_setup_wizard:main',
            'tezos-voting-wizard=tezos_baking.tezos_voting_wizard:main',
        ]
    )
)
